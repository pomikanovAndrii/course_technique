package com.example.CourseTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseTestApplication.class, args);
	}

}
