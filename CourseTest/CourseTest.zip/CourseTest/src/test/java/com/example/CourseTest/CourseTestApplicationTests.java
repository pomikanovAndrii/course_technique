package com.example.CourseTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
